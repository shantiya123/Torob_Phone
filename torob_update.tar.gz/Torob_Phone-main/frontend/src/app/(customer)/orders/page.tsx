import type { Metadata } from "next";
import { RequireRole } from "@/features/auth/components/guards";
import { OrderHistoryExperience } from "@/features/orders/components/order-history-experience";

export const metadata: Metadata = {
  title: "سفارش‌های من | ترب‌فون",
  robots: { index: false, follow: false },
};

export default function OrdersPage() {
  return (
    <RequireRole role="customer">
      <OrderHistoryExperience />
    </RequireRole>
  );
}
