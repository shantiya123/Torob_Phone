# Task Groups Roadmap

- [x] TG-007: Backend stabilization, security, and integration.
- [x] TG-008: AI personalized phone explanation and saved search intent.
- [x] TG-009: Torobche conversational backend contract.
- [x] TG-010: Customer orders frontend contract.
- [x] TG-011: Minimal phone image support.
- [x] TG-012: Store catalog browsing API.
- [x] TG-013: PostgreSQL readiness and secure HttpOnly JWT authentication.
- [x] TG-019: Torobche empty-result recovery search.

This is a planning baseline, not a commitment. Priorities and boundaries should be revised as real product and operational requirements emerge.

## Phase 1 — Foundation

- [x] TG-001: Repository foundation and architecture baseline
- [x] TG-002: Canonical data architecture and database design
- [ ] Establish reproducible dependency and environment configuration.
- [x] TG-003: Implement the catalog app, migrations, and validated import boundary.

## Phase 2 — Product Data Model

- [ ] Define canonical product, specification, store, and offer models.
- [ ] Add migrations, data-integrity rules, and focused model tests.

## Phase 3 — Data Normalization

- [ ] Define normalized specification vocabulary, units, and validation.
- [ ] Establish a boundary for importing untrusted external product data.

## Phase 4 — Product and Offer Data

- [ ] Build approved workflows/APIs for product and offer data.
- [ ] Define freshness, source provenance, and duplicate-handling behavior.

## Phase 5 — Deterministic Recommendation Engine

- [x] TG-004: Implement hard-constraint filtering.
- [ ] Implement deterministic scoring, ranking, and data-backed explanations.

## Phase 6 — Search

- [ ] Define search requirements and add product discovery capabilities.

## Phase 7 — LLM Integration

- [x] TG-005: Introduce a stateful LLM query-modification abstraction over deterministic filtering.
- [ ] Interpret natural-language preferences into broader validated structured intent.

## Phase 8 — Conversational Experience

- [ ] Add a conversational interface around the validated search and recommendation capabilities.

## API Delivery

- [x] TG-006: Implement the documented DRF API views, JWT authentication, permissions, pagination, and routing.

## Phase 9 — Testing and Integration

- [ ] Expand unit, integration, API-contract, and end-to-end coverage.
- [ ] Validate data, performance, and error-handling boundaries.

## Phase 10 — Deployment

- [ ] Define production settings, secret management, database strategy, observability, and deployment automation.
